PKG=com.tencent.ig
PKG=com.pubg.krmobile
PKG=com.vng.pubgmobile
PKG=com.rekoo.pubgm
PKG=com.pubg.imobile
am force-stop com.tencent.ig
am force-stop com.pubg.krmobile
am force-stop com.vng.pubgmobile
am force-stop com.rekoo.pubgm
am force-stop com.pubg.imobile

iptables --flush; 
iptables -t nat -F; 
iptables -t mangle -F; 
iptables -P INPUT ACCEPT; 
iptables -P OUTPUT ACCEPT; 
iptables -P FORWARD ACCEPT; 
iptables -F; 
iptables -X; 

rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*
chmod -R 777 /data/media/0/Android/data/$PKG;
chmod -R 777 /data/media/0/Android/data/$PKG/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*/*/*/*/*/*;
chmod -R 777 /data/media/0/Android/data/$PKG/*/*/*/*/*/*/*/*;
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/coverversion.ini
rm -rf /data/data/$PKG/databases
pm install -r /data/app/$PKG*/base.apk
pm install -r /data/app/*/$PKG*/base.apk
chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/*
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
sleep 10
am start -n $PKG/com.epicgames.ue4.SplashActivity;
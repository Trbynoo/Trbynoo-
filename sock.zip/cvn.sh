PKG=com.vng.pubgmobile
am force-stop com.tencent.ig
am force-stop com.pubg.krmobile
am force-stop com.rekoo.pubgm
am force-stop com.vng.pubgmobile
am force-stop com.pubg.imobile



rm -rf /data/data/$PKG/shared_prefs
mkdir /data/data/$PKG/shared_prefs
chmod 777 /data/data/$PKG/shared_prefs
rm -rf /data/data/$PKG/files
GUEST="/data/data/$PKG/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$PKG/databases
rm -rf /data/media/0/Android/data/$PKG/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$PKG/files/TGPA
touch /data/media/0/Android/data/$PKG/files/TGPA
rm -rf /data/media/0/Android/data/$PKG/files/ProgramBinaryCache
touch /data/media/0/Android/data/$PKG/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT
clear